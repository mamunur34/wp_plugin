<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://wirkaufen24.de/
 * @since      1.0.0
 *
 * @package    Mr_freshsales
 * @subpackage Mr_freshsales/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Mr_freshsales
 * @subpackage Mr_freshsales/includes
 * @author     Md Mamunur Rasid <mamunandroid48@gmail.com>
 */
class Mr_freshsales_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
