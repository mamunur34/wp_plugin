<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://wirkaufen24.de/
 * @since             1.0.0
 * @package           Mr_freshsales
 *
 * @wordpress-plugin
 * Plugin Name:       Mr FreshSales
 * Plugin URI:        https://wirkaufen24.de/
 * Description:       This is a custom built WordPress Plug-in for Wirkaufen24 to coupe with FreshSales
 * Version:           1.0.0
 * Author:            Md Mamunur Rasid
 * Author URI:        https://wirkaufen24.de/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       mr_freshsales
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'MR_FRESHSALES_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-mr_freshsales-activator.php
 */
function activate_mr_freshsales() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-mr_freshsales-activator.php';
	Mr_freshsales_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-mr_freshsales-deactivator.php
 */
function deactivate_mr_freshsales() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-mr_freshsales-deactivator.php';
	Mr_freshsales_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_mr_freshsales' );
register_deactivation_hook( __FILE__, 'deactivate_mr_freshsales' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-mr_freshsales.php';
require plugin_dir_path( __FILE__ ) . 'includes/freshsales/FreshsalesAnalytics.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_mr_freshsales() {

	$plugin = new Mr_freshsales();
	$plugin->run();
	
	
	
FreshsalesAnalytics::init(array(
   'domain' =>  "https://immo1.freshsales.io",
    'app_token' => "c5b8c5d9d8eb4f97fce4c834f56cba432c8c7e765b8d9e09c6742fa6561a13df"
));
/*
FreshsalesAnalytics::identify(array(
    'identifier' => "john@abc.com",
    'Last name' => "Doe",
    'company' => array(
    	'Name' => "Sample Company"
    ),
    'deal' => array(
    	'Name' => "Sample Deal"
    )
));
FreshsalesAnalytics::trackEvent(array(
    'identifier' => 'john@abc.com',
    'name' => 'Sample Event Name',
    'prop1' => 'value1', //Custom Property
    'prop2' => 'value2' //Custom Property
));
*/
if(!function_exists('wp_get_current_user')) {
    include(ABSPATH . "wp-includes/pluggable.php"); 
}
$current_user = wp_get_current_user();



$user_email =  $current_user->user_email ;
if (strlen($user_email)> 3){
	
	$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";

	 
	$current_url =   $actual_link;

	FreshsalesAnalytics::trackPageView(array(
	   'identifier' => esc_html($user_email),
		'url' => $current_url
	));

	//echo $user_email;
	//echo "<br>";
	//echo $current_url;

}else{
	//echo "<h1>User is not logged in</h1>";
}



}
run_mr_freshsales();
