<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://wirkaufen24.de/
 * @since      1.0.0
 *
 * @package    Mr_freshsales
 * @subpackage Mr_freshsales/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Mr_freshsales
 * @subpackage Mr_freshsales/includes
 * @author     Md Mamunur Rasid <mamunandroid48@gmail.com>
 */
class Mr_freshsales_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'mr_freshsales',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
