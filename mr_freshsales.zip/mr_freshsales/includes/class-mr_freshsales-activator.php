<?php

/**
 * Fired during plugin activation
 *
 * @link       https://wirkaufen24.de/
 * @since      1.0.0
 *
 * @package    Mr_freshsales
 * @subpackage Mr_freshsales/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Mr_freshsales
 * @subpackage Mr_freshsales/includes
 * @author     Md Mamunur Rasid <mamunandroid48@gmail.com>
 */
class Mr_freshsales_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
